window.config={
  //serverURL:'http://localhost:3000/'
  //serverURL:'http://192.168.254.1:8080/'
  //serverURL:'http://192.168.20.32:8080/'
  serverURL: window.location.origin + '/'
};
